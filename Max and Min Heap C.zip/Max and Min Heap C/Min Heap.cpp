#include<stdio.h>

int heap[100] = {0};
int element = 0;

void swap(int *a, int *b){
	int c = *a;
	*a = *b;
	*b = c;
}

void up_heap(int index){
	// jika index == index dari root (1) maka tidak perlu di lanjutkan
	if(index == 1){
		return;
	}
	int parent = index / 2;
	
	if(heap[index] < heap[parent]){
		swap(&heap[index], &heap[parent]);
		up_heap(parent);
	}
}

void insert_heap(int value){
	element++;
	heap[element] = value;
	
	up_heap(element);
}

void view_heap(){
	int i;
	for (i = 1; i <= element; i++){
		printf("%d", heap[i]);
		i == element?printf("\n"):printf(" | ");
	}
}

void down_heap(int index){
	int to_index = index;
	
	int aKi = 2 * index;
	int aKa = 2 * index + 1;
	
	if(aKi <= element && heap[to_index] > heap[aKi]){
		to_index = aKi;
	}
	if(aKa <= element && heap[to_index] > heap[aKa]){
		to_index = aKa;
	}
	if(to_index == index){
		return;
	}
	swap(&heap[index], &heap[to_index]);
	
	down_heap(to_index);
}

int extract_min(){
	//jika tidak ada data
	if(element == 0){
		printf("Heap Kosong");
		return 0;
	}
	// cuma 1
	if (element == 1){
		element--;
		return heap[1];
	}
	//jika lebih dari 1
	int return_value = heap[1];
	// tukar data root dengan array terakhir
	swap(&heap[1], &heap[element]);
	element--;
	
	down_heap(1);
	
	return return_value;
}

int main(){
	
	insert_heap(30);
	insert_heap(40);
	insert_heap(50);
	insert_heap(35);
	insert_heap(20);
	insert_heap(10);
	insert_heap(5);
	
	view_heap();
	
	printf("deleted: %d\n", extract_min());
	view_heap();
	printf("deleted: %d\n", extract_min());
	view_heap();
	printf("deleted: %d\n", extract_min());
	view_heap();
	return 0;
}
