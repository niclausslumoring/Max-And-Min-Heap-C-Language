#include<stdio.h>
#include<stdbool.h>

int parent(int pos){
	int a = pos/2;
	if(a == 0){
		return 1;
	}
	return a;
}

void swap(int* heap, int a, int b){
	int temp = heap[a];
	heap[a] = heap[b];
	heap[b] = temp;
}

int insert(int* heap, int size, int value){
	size += 1;
	heap[size] = value;
	
	int pos = size;
	while(heap[pos] > heap[parent(pos)]){
		swap(heap, pos, parent(pos));
		pos = parent(pos);
	}
	
	return size;
}

void print_heap(int* heap, int size){
	int i;
	for(i = 1; i <= size/2; i++){
		printf("Parent: %d, left child: %d, right child: %d \n",
		heap[i], heap[2*i], heap[2*i+1]);
	}
}

int get_max(int* heap){
	return heap[1];
}

bool is_leaf(int pos, int size){
	if(pos >= (size/2) && pos<= size){
		return true;
	}
	return false;
}

int left_child(int pos){
	return 2*pos;
}

int right_child(int pos){
	return 2 * pos + 1;
}

void max_heapify(int* heap, int pos, int size){
	if(is_leaf(pos, size)){
		return;
	}
	int leftChildValue = heap[left_child(pos)];
	int rightChildValue = heap[right_child(pos)];
	
	if(heap[pos] < leftChildValue || heap[pos] < rightChildValue){
		if(leftChildValue > rightChildValue){
			swap(heap, pos, left_child(pos));
			max_heapify(heap, left_child(pos), size);
		}
		else{
			swap(heap, pos, right_child(pos));
			max_heapify(heap, right_child(pos), size);
		}
	}
}

int extract_max(int* heap, int* size){
	int maxValue = get_max(heap);
	heap[1] = heap[*size];
	*size -= 1;
	
	max_heapify(heap, 1, *size);
	return maxValue;
}

int main (){
	
	int heap[100] = {};
	int size = 0;
	
	size = insert(heap, size, 17);
	size = insert(heap, size, 16);
	size = insert(heap, size, 13);
	size = insert(heap, size, 12);
	size = insert(heap, size, 19);
//	size = insert(heap, size, 29);
	
	print_heap(heap, size);
	
	int maxValue = get_max(heap);
	printf("Current Max Value: %d\n", maxValue);
	
	maxValue = extract_max(heap, &size);
	printf("Max Value after extracted: %d\n", maxValue);
	
	maxValue = get_max(heap);
	printf("Current Max Value: %d\n", maxValue);
	
	return 0;
}
